"use client"

import { motion } from "framer-motion"

interface MessageProps {
  message: string
  onNext: () => void
}

export default function Message({ message, onNext }: MessageProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -50 }}
      transition={{ duration: 0.5 }}
      className="text-center mb-8"
    >
      <p className="text-2xl mb-4">{message}</p>
      <button
        onClick={onNext}
        className="px-4 py-2 bg-[#ff4b4b] text-white rounded-full hover:bg-[#ff6b6b] transition-colors"
      >
        Далее
      </button>
    </motion.div>
  )
}

