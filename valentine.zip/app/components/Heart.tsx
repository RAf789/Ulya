"use client"

import { motion } from "framer-motion"

export default function Heart() {
  return (
    <motion.div
      initial={{ scale: 0 }}
      animate={{ scale: [0, 1.2, 1] }}
      transition={{
        duration: 1.5,
        times: [0, 0.6, 1],
        ease: "easeInOut",
      }}
      className="relative w-64 h-64 mb-8"
    >
      <motion.div
        animate={{
          scale: [1, 1.1, 1],
        }}
        transition={{
          duration: 1.5,
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "reverse",
        }}
        className="absolute inset-0"
      >
        <svg viewBox="0 0 32 29.6" className="fill-[#ff4b4b]">
          <path
            d="M23.6,0c-3.4,0-6.3,2.7-7.6,5.6C14.7,2.7,11.8,0,8.4,0C3.8,0,0,3.8,0,8.4c0,9.4,9.5,11.9,16,21.2
          c6.1-9.3,16-12.1,16-21.2C32,3.8,28.2,0,23.6,0z"
          />
        </svg>
      </motion.div>
    </motion.div>
  )
}

