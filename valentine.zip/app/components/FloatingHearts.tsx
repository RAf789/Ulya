"use client"

import { motion } from "framer-motion"

export default function FloatingHearts() {
  const hearts = Array(20).fill(null)

  return (
    <div className="fixed inset-0 pointer-events-none">
      {hearts.map((_, index) => (
        <motion.div
          key={index}
          initial={{
            opacity: 0,
            scale: 0,
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
          }}
          animate={{
            opacity: [0, 1, 0],
            scale: [0, 1, 0],
            y: [null, -100],
          }}
          transition={{
            duration: Math.random() * 3 + 2,
            repeat: Number.POSITIVE_INFINITY,
            delay: Math.random() * 5,
          }}
          className="absolute text-[#ff4b4b]"
        >
          ❤
        </motion.div>
      ))}
    </div>
  )
}

