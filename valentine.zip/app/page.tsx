"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Heart from "./components/Heart"
import FloatingHearts from "./components/FloatingHearts"
import Message from "./components/Message"

export default function Home() {
  const [showMessage, setShowMessage] = useState(false)
  const [currentMessage, setCurrentMessage] = useState(0)

  const messages = [
    "Ульяна, ты - мое вдохновение",
    "С тобой каждый день - особенный",
    "Ты делаешь мою жизнь ярче",
    "Я люблю тебя всем сердцем",
  ]

  useEffect(() => {
    const timer = setTimeout(() => setShowMessage(true), 2000)
    return () => clearTimeout(timer)
  }, [])

  const nextMessage = () => {
    setCurrentMessage((prev) => (prev + 1) % messages.length)
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-b from-[#4a0e1c] to-[#3d0a17] text-white overflow-hidden">
      <FloatingHearts />
      <motion.h1
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
        className="text-4xl md:text-6xl font-bold mb-8 text-center"
      >
        С Днём Святого Валентина, Ульяна!
      </motion.h1>
      <Heart />
      <AnimatePresence mode="wait">
        {showMessage && <Message key={currentMessage} message={messages[currentMessage]} onNext={nextMessage} />}
      </AnimatePresence>
    </main>
  )
}

